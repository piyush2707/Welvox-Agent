import type { Skill, ToolCall } from '@welvox/types';
import { orchestrator } from './orchestrator';

export interface RoutingRequest {
  toolName: string;
  parameters: Record<string, unknown>;
  context: Record<string, unknown>;
}

export interface RoutingResult {
  skill: Skill | null;
  tool: any;
  success: boolean;
  error?: string;
  response: unknown;
}

export class ToolRouter {
  /**
   * Route a tool call to the appropriate skill
   */
  async routeToolCall(toolCall: ToolCall, context: Record<string, unknown>): Promise<RoutingResult> {
    // Find the skill that provides this tool
    const skills = orchestrator.getSkills();
    let matchedSkill: Skill | null = null;
    let matchedTool = null;

    for (const skill of skills) {
      for (const tool of skill.tools) {
        if (tool.id === toolCall.name || tool.name === toolCall.name) {
          matchedSkill = skill;
          matchedTool = tool;
          break;
        }
      }
      if (matchedSkill) break;
    }

    if (!matchedSkill || !matchedTool) {
      return {
        skill: null,
        tool: null,
        success: false,
        error: `Tool not found: ${toolCall.name}`,
        response: null,
      };
    }

    // Execute the tool
    try {
      const response = await this.executeTool(matchedTool, toolCall.arguments, context);

      return {
        skill: matchedSkill,
        tool: matchedTool,
        success: true,
        response,
      };
    } catch (error) {
      return {
        skill: matchedSkill,
        tool: matchedTool,
        success: false,
        error: String(error),
        response: null,
      };
    }
  }

  /**
   * Route a request to the best matching skill
   */
  async routeSkillRequest(request: RoutingRequest): Promise<RoutingResult> {
    const skills = orchestrator.getSkills();

    // Find the best matching skill based on tool requirements
    let bestSkill: Skill | null = null;
    let bestScore = 0;

    for (const skill of skills) {
      const score = this.calculateSkillMatch(skill, request);
      if (score > bestScore) {
        bestScore = score;
        bestSkill = skill;
      }
    }

    if (!bestSkill) {
      return {
        skill: null,
        tool: null,
        success: false,
        error: 'No matching skill found',
        response: null,
      };
    }

    try {
      const response = await this.executeSkill(bestSkill, request, bestScore);

      return {
        skill: bestSkill,
        tool: null,
        success: true,
        response,
      };
    } catch (error) {
      return {
        skill: bestSkill,
        tool: null,
        success: false,
        error: String(error),
        response: null,
      };
    }
  }

  /**
   * Calculate how well a skill matches a request
   */
  private calculateSkillMatch(skill: Skill, request: RoutingRequest): number {
    let score = 0;

    // Check if skill has the requested tool
    if (skill.tools.some((t) => t.id === request.toolName || t.name === request.toolName)) {
      score += 100;
    }

    // Check if skill's tags match request
    const requestTags = (request.parameters.tags as string[]) || [];
    const matchingTags = skill.metadata.tags.filter((tag) => requestTags.includes(tag));
    score += matchingTags.length * 10;

    // Check if skill is enabled
    if (skill.enabled) {
      score += 5;
    }

    return score;
  }

  /**
   * Execute a tool
   */
  private async executeTool(
    tool: any,
    parameters: Record<string, unknown>,
    context: Record<string, unknown>
  ): Promise<unknown> {
    // Simulate tool execution
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          toolId: tool.id,
          toolName: tool.name,
          parameters,
          result: `Executed ${tool.name}`,
          timestamp: new Date().toISOString(),
        });
      }, 100);
    });
  }

  /**
   * Execute a skill
   */
  private async executeSkill(
    skill: Skill,
    request: RoutingRequest,
    matchScore: number
  ): Promise<unknown> {
    // Simulate skill execution
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          skillId: skill.id,
          skillName: skill.name,
          matchScore,
          request,
          result: `Executed skill: ${skill.name}`,
          timestamp: new Date().toISOString(),
        });
      }, 100);
    });
  }
}

export const toolRouter = new ToolRouter();
