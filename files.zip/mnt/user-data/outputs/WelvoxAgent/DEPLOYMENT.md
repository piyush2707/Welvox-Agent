# WelvoxAgent Deployment Guide

## Overview

This guide covers deploying WelvoxAgent to production environments including Docker, Kubernetes, and cloud platforms.

## Prerequisites

- Docker & Docker Compose
- kubectl (for Kubernetes)
- Helm (optional)
- Cloud CLI (AWS, GCP, or Azure)

## Local Development

### Using Docker Compose

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Reset everything
docker-compose down -v  # -v removes volumes
```

Services available:
- Frontend: http://localhost:3000
- API: http://localhost:8000
- API Docs: http://localhost:8000/docs
- Database: localhost:5432
- Redis: localhost:6379
- Qdrant: http://localhost:6333

## Docker Build

### Build Images

```bash
# Build API image
docker build -f Dockerfile.api -t welvox-api:latest .

# Build Web image
docker build -f Dockerfile.web -t welvox-web:latest .

# Build both
pnpm docker:build
```

### Run Container

```bash
# Run API
docker run \
  -p 8000:8000 \
  -e DATABASE_URL=postgresql://... \
  -e ANTHROPIC_API_KEY=... \
  welvox-api:latest

# Run Web
docker run \
  -p 3000:3000 \
  -e NEXT_PUBLIC_API_URL=http://localhost:8000 \
  welvox-web:latest
```

## Kubernetes Deployment

### Prerequisites

- Kubernetes cluster (1.24+)
- kubectl configured
- Persistent storage class

### Create Namespace

```bash
kubectl create namespace welvox
```

### Deploy with Helm

Create `values.yaml`:

```yaml
# values.yaml
api:
  image: welvox-api:latest
  replicas: 3
  resources:
    requests:
      memory: "256Mi"
      cpu: "250m"
    limits:
      memory: "512Mi"
      cpu: "500m"

web:
  image: welvox-web:latest
  replicas: 2
  resources:
    requests:
      memory: "128Mi"
      cpu: "100m"

postgres:
  enabled: true
  storage: 20Gi

redis:
  enabled: true
  storage: 5Gi

qdrant:
  enabled: true
  storage: 50Gi

ingress:
  enabled: true
  domain: welvox.example.com
  tls: true
```

Deploy:

```bash
helm install welvox ./helm -f values.yaml -n welvox

# Check status
kubectl get all -n welvox

# View logs
kubectl logs -f deployment/welvox-api -n welvox
```

### Manual Kubernetes Manifests

See `k8s/` directory for raw manifests.

```bash
# Apply manifests
kubectl apply -f k8s/ -n welvox

# Check deployments
kubectl rollout status deployment/welvox-api -n welvox
```

## Cloud Platform Deployment

### AWS ECS/EKS

```bash
# Create ECR repository
aws ecr create-repository --repository-name welvox-api
aws ecr create-repository --repository-name welvox-web

# Build and push
aws ecr get-login-password --region us-east-1 | docker login \
  --username AWS --password-stdin <account>.dkr.ecr.us-east-1.amazonaws.com

docker build -f Dockerfile.api -t <account>.dkr.ecr.us-east-1.amazonaws.com/welvox-api:latest .
docker push <account>.dkr.ecr.us-east-1.amazonaws.com/welvox-api:latest
```

### Google Cloud Run

```bash
# Build with Cloud Build
gcloud builds submit --config=cloudbuild.yaml

# Deploy
gcloud run deploy welvox-api \
  --image gcr.io/PROJECT-ID/welvox-api:latest \
  --platform managed \
  --region us-central1 \
  --set-env-vars DATABASE_URL=postgresql://...
```

### Azure Container Instances

```bash
# Build image
az acr build --registry <registry-name> \
  --image welvox-api:latest -f Dockerfile.api .

# Deploy
az container create \
  --resource-group myResourceGroup \
  --name welvox-api \
  --image <registry>.azurecr.io/welvox-api:latest \
  --ports 8000 \
  --environment-variables \
    DATABASE_URL=postgresql://... \
    ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY
```

## Environment Configuration

### Production .env

```env
# Application
ENVIRONMENT=production
DEBUG=false
LOG_LEVEL=INFO

# Database
DATABASE_URL=postgresql://user:password@host:5432/welvox
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=40

# Redis
REDIS_URL=redis://host:6379

# Vector DB
QDRANT_URL=https://qdrant.example.com
QDRANT_API_KEY=<secure-key>

# AI Keys (use secrets management)
ANTHROPIC_API_KEY=<from-vault>
OPENAI_API_KEY=<from-vault>

# Auth
CLERK_SECRET_KEY=<from-vault>

# Security
SECRET_KEY=<generate-strong-random>
ALLOWED_ORIGINS=https://app.example.com

# Monitoring
SENTRY_DSN=https://...
```

## Database Setup

### Migrations

```bash
# Run migrations
alembic upgrade head

# Create user
psql -U postgres -c "CREATE USER welvox WITH PASSWORD 'secure_password';"

# Create database
psql -U postgres -c "CREATE DATABASE welvox_ai OWNER welvox;"

# Run migrations
alembic upgrade head
```

### Backup & Recovery

```bash
# Backup
pg_dump -U welvox -h localhost welvox_ai > backup.sql

# Restore
psql -U welvox -h localhost welvox_ai < backup.sql

# Automated backups (cron)
0 2 * * * pg_dump -U welvox -h localhost welvox_ai | gzip > /backups/welvox_$(date +\%Y\%m\%d).sql.gz
```

## SSL/TLS Certificates

### Self-signed (Development)

```bash
openssl req -x509 -newkey rsa:4096 -nodes -out cert.pem -keyout key.pem -days 365
```

### Let's Encrypt (Production)

```bash
# Using Certbot
certbot certonly --standalone -d welvox.example.com

# Kubernetes cert-manager
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml
```

## Health Checks

### HTTP Health Endpoint

```bash
curl http://localhost:8000/health
curl http://localhost:8000/health/detailed
```

### Kubernetes Probes

```yaml
spec:
  containers:
  - name: api
    livenessProbe:
      httpGet:
        path: /health
        port: 8000
      initialDelaySeconds: 30
      periodSeconds: 10
    readinessProbe:
      httpGet:
        path: /health
        port: 8000
      initialDelaySeconds: 5
      periodSeconds: 5
```

## Monitoring & Logging

### Prometheus Metrics

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'welvox-api'
    static_configs:
      - targets: ['localhost:8000']
```

### ELK Stack

```bash
# Deploy Elasticsearch
docker run -d -p 9200:9200 docker.elastic.co/elasticsearch/elasticsearch:8.0.0

# Deploy Logstash
# Deploy Kibana
docker run -d -p 5601:5601 docker.elastic.co/kibana/kibana:8.0.0
```

### Sentry Error Tracking

```python
# In FastAPI app
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration

sentry_sdk.init(
    dsn="https://key@sentry.io/project",
    integrations=[FastApiIntegration()],
    traces_sample_rate=0.1,
    environment="production"
)
```

## Scaling

### Horizontal Scaling

```bash
# Kubernetes
kubectl scale deployment welvox-api --replicas=5

# Docker Swarm
docker service scale welvox-api=5
```

### Load Balancing

- **Nginx**: Reverse proxy, load balancing
- **HAProxy**: Advanced load balancer
- **Cloud LB**: AWS ELB, GCP LB, Azure LB

### Database Scaling

```sql
-- Read replicas
CREATE PUBLICATION welvox_pub FOR ALL TABLES;

-- Connection pooling (PgBouncer)
-- Configure in pgbouncer.ini
```

### Caching

- **Redis Cluster**: For high availability
- **CDN**: For static assets (Cloudflare, AWS CloudFront)

## Disaster Recovery

### Backup Strategy

1. **Daily**: Incremental backups
2. **Weekly**: Full backups
3. **Monthly**: Archived backups
4. **Replication**: Multi-region replication

### Recovery Plan

```bash
# RTO: Recovery Time Objective = 1 hour
# RPO: Recovery Point Objective = 1 hour

# Test recovery monthly
./scripts/test_recovery.sh
```

### High Availability

- Multiple instances (3+)
- Load balanced
- Database replication
- Automated failover
- Health checks

## Performance Optimization

### API Optimization

```python
# Enable compression
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Cache responses
from fastapi_cache2 import FastAPICache2
from fastapi_cache2.decorator import cache

@router.get("/cached-endpoint")
@cache(expire=3600)
async def cached_endpoint():
    return {"data": "cached"}
```

### Database Optimization

```sql
-- Create indexes
CREATE INDEX idx_user_email ON users(email);
CREATE INDEX idx_conversation_user_id ON conversations(user_id);
CREATE INDEX idx_memory_embedding ON memory USING ivfflat (embedding);

-- Analyze query plans
EXPLAIN ANALYZE SELECT * FROM users WHERE email = 'test@example.com';
```

### Frontend Optimization

```bash
# Next.js production build
npm run build

# Image optimization
npm install next-image-export-optimizer

# Code splitting
dynamic(() => import('../components/Heavy'), { loading: () => <p>...</p> })
```

## Security Hardening

### Application Security

- ✅ HTTPS/TLS everywhere
- ✅ CORS properly configured
- ✅ Rate limiting enabled
- ✅ Input validation
- ✅ SQL injection prevention (ORM)
- ✅ CSRF protection
- ✅ XSS prevention

### Infrastructure Security

- ✅ Firewall rules
- ✅ Network policies
- ✅ Secrets in vault (AWS Secrets Manager, HashiCorp Vault)
- ✅ IAM roles & permissions
- ✅ Network encryption (VPN, private networks)
- ✅ DDoS protection (WAF)

### Database Security

- ✅ Strong passwords
- ✅ Encryption at rest & in transit
- ✅ Regular backups
- ✅ Access controls
- ✅ Audit logging

## Troubleshooting

### Common Issues

**Services not starting**
```bash
# Check logs
docker-compose logs api
docker-compose logs postgres

# Verify network
docker network ls
docker network inspect welvox_default
```

**Database connection errors**
```bash
# Check connection
psql -U welvox -h localhost -c "SELECT 1;"

# Reset password
ALTER USER welvox WITH PASSWORD 'newpassword';
```

**Memory/CPU issues**
```bash
# Check resource usage
docker stats

# Increase limits
# Edit docker-compose.yml resources section

# Monitor Kubernetes
kubectl top nodes
kubectl top pods
```

## Maintenance

### Regular Tasks

- [ ] Database maintenance (vacuum, analyze)
- [ ] Log rotation
- [ ] Certificate renewal (60 days before expiry)
- [ ] Security updates
- [ ] Performance tuning
- [ ] Backup verification

### Update Procedure

```bash
# 1. Test in staging
git checkout main && git pull
pnpm install && pnpm build

# 2. Database migration
pnpm db:migrate

# 3. Blue-green deployment
# Deploy new version to separate environment
# Test thoroughly
# Switch traffic

# 4. Rollback procedure
# Keep previous version ready
# Fast rollback if issues
```

## Monitoring Checklist

- [ ] Uptime monitoring (Uptime Robot, Datadog)
- [ ] Error rate tracking (Sentry, New Relic)
- [ ] Performance metrics (response time, latency)
- [ ] Resource usage (CPU, memory, disk)
- [ ] Database health
- [ ] API health endpoints
- [ ] Security logs
- [ ] User activity logs

---

For more help, see troubleshooting or contact support.
