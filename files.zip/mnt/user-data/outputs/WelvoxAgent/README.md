# WelvoxAgent - Universal AI Operating System

**One AI. Infinite Skills.**

WelvoxAgent is a production-grade Universal AI Operating System that intelligently understands user requests, breaks them into subtasks, selects appropriate AI skills and tools, and delivers complete results.

## 🌟 What is WelvoxAgent?

- **Not a chatbot** - It's an intelligent orchestration engine
- **Multi-skill AI** - 22+ specialized AI skills for different domains
- **Autonomous execution** - Plans and executes complex tasks end-to-end
- **Tool integration** - Connects to 17+ external services (GitHub, Gmail, Slack, etc.)
- **Memory system** - Long-term, short-term, and semantic memory with RAG
- **Enterprise ready** - Production security, scaling, and compliance

### Key Features

✅ **Intelligent Intent Detection** - Understands what you actually need  
✅ **Automatic Task Decomposition** - Breaks complex requests into subtasks  
✅ **Multi-Provider AI** - Uses Claude, OpenAI, Gemini, or OpenRouter  
✅ **Streaming Responses** - Real-time updates and progress indication  
✅ **Tool Calling** - Integrates with 17+ external services  
✅ **Memory & RAG** - Maintains context and learns from past interactions  
✅ **Background Jobs** - Run long-running tasks asynchronously  
✅ **Dark Mode** - Beautiful, responsive UI  
✅ **Fully Typed** - TypeScript + Python type hints  
✅ **Dockerized** - One-command deployment  

## 🏗️ Architecture

### Tech Stack

**Frontend**
- Next.js 15 + React 18
- TypeScript + Tailwind CSS
- Clerk Authentication
- Framer Motion for animations

**Backend**
- FastAPI (Python 3.11)
- LangGraph for AI orchestration
- PostgreSQL for data
- Redis for caching & jobs
- Qdrant for vector search

**Infrastructure**
- Docker & Docker Compose
- GitHub Actions CI/CD
- Kubernetes-ready

### Project Structure

```
WelvoxAgent/
├── apps/
│   ├── web/              # Next.js frontend
│   └── api/              # FastAPI backend
├── packages/
│   ├── ui/               # React component library
│   ├── agents/           # Orchestration engine
│   ├── skills/           # AI skill definitions
│   ├── memory/           # Memory & RAG system
│   ├── database/         # Schema & migrations
│   ├── auth/             # Authentication
│   ├── integrations/     # Tool connectors
│   ├── prompts/          # LLM templates
│   ├── types/            # Shared types
│   └── utils/            # Utilities
├── docker-compose.yml    # Local development
├── pnpm-workspace.yaml   # Monorepo config
└── README.md             # This file
```

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- Python 3.11+
- Docker & Docker Compose
- pnpm package manager

### 1. Clone & Setup

```bash
git clone https://github.com/yourusername/WelvoxAgent.git
cd WelvoxAgent

# Install dependencies
pnpm install

# Copy environment file
cp .env.example .env.local

# Edit .env.local with your API keys
```

### 2. Configure API Keys

Edit `.env.local` and add your keys:

```env
# Required
ANTHROPIC_API_KEY=sk-ant-xxx
OPENAI_API_KEY=sk-xxx

# Optional (pick at least one)
GOOGLE_API_KEY=xxx
OPENROUTER_API_KEY=xxx

# Authentication
CLERK_SECRET_KEY=xxx
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=xxx
```

### 3. Start Services

```bash
# Using Docker Compose (recommended)
docker-compose up -d

# Or manually start each service
pnpm db:migrate           # Run database migrations
pnpm run dev              # Start dev servers
```

### 4. Access the App

- **Frontend**: http://localhost:3000
- **API Docs**: http://localhost:8000/docs
- **Admin**: http://localhost:5555 (Flower/Celery)

## 📚 Development

### Project Commands

```bash
# Development
pnpm dev                  # Start all services
pnpm build                # Build all packages
pnpm test                 # Run all tests
pnpm lint                 # Lint all code

# Database
pnpm db:migrate           # Run migrations
pnpm db:seed              # Seed sample data
pnpm db:reset             # Reset database

# Docker
pnpm docker:build         # Build Docker images
pnpm docker:up            # Start containers
pnpm docker:down          # Stop containers
pnpm docker:logs          # View logs
```

### File Structure Details

#### Frontend (`apps/web`)
- `/src/app` - Next.js app router pages
- `/src/components` - React components
- `/src/lib` - Utility functions
- `/src/hooks` - Custom React hooks

#### Backend (`apps/api`)
- `/core` - Configuration, database, Redis, Vector DB
- `/routers` - API endpoints
- `/models` - SQLAlchemy ORM models
- `/services` - Business logic
- `/schemas` - Pydantic request/response schemas

#### Packages
- `agents` - Core orchestration engine
- `skills` - AI skill implementations
- `memory` - Conversation & semantic memory
- `database` - Database migrations
- `types` - Shared TypeScript types

## 🎯 Using WelvoxAgent

### Basic Chat

```typescript
const response = await fetch('http://localhost:8000/api/agents/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    message: "Build me a startup website"
  })
})
```

### Stream Responses

```typescript
const response = await fetch('http://localhost:8000/api/agents/chat/stream', {
  method: 'POST',
  body: JSON.stringify({ message: "Your request" })
})

const reader = response.body.getReader()
// Process streaming chunks...
```

### Create Custom Skill

See `SKILLS.md` for detailed skill development guide.

## 🔧 Configuration

### Environment Variables

See `.env.example` for all available options.

### Database Migrations

```bash
# Create new migration
alembic revision --autogenerate -m "Description"

# Run migrations
pnpm db:migrate
```

### Redis Queue

Jobs are automatically queued and processed in background.

```python
# In your code
from core.redis_client import redis_client

# Queue a job
await redis_client.lpush('jobs', {
  'type': 'process_file',
  'data': {...}
})
```

## 🧪 Testing

```bash
# Unit tests
pnpm test

# Watch mode
pnpm test:watch

# Coverage
pnpm test -- --coverage
```

## 📦 Deployment

### Docker Deployment

```bash
# Build images
docker build -f Dockerfile.api -t welvox-api:latest .
docker build -f Dockerfile.web -t welvox-web:latest .

# Run containers
docker run -p 8000:8000 welvox-api:latest
docker run -p 3000:3000 welvox-web:latest
```

### Kubernetes Deployment

Kubernetes manifests are in `k8s/` directory:

```bash
kubectl apply -f k8s/
```

### GitHub Actions CI/CD

Automatically runs on push to `main` and `develop`:
- Lint & type check
- Unit & integration tests
- Security scanning
- Docker image build & push

## 📖 Documentation

- **[ARCHITECTURE.md](./ARCHITECTURE.md)** - Detailed system design
- **[API.md](./API.md)** - API reference
- **[SKILLS.md](./SKILLS.md)** - Building custom skills
- **[DEPLOYMENT.md](./DEPLOYMENT.md)** - Production deployment

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📋 Available Skills

### Default Skills (22)

1. **Universal Assistant** - General-purpose AI helper
2. **Coding Assistant** - Code generation & debugging
3. **Research Agent** - Deep research & information gathering
4. **File Analyzer** - Document & file analysis
5. **PDF Reader** - Extract text & data from PDFs
6. **Spreadsheet Analyzer** - Analyze & transform data
7. **Email Writer** - Compose professional emails
8. **Presentation Generator** - Create slide decks
9. **Image Analyzer** - Analyze & describe images
10. **Travel Planner** - Plan trips & itineraries
11. **Business Consultant** - Business strategy & advice
12. **Startup Advisor** - Startup-specific guidance
13. **Marketing Expert** - Marketing strategies & campaigns
14. **Content Creator** - Blog posts, social media, etc.
15. **Social Media Manager** - Manage social accounts
16. **Data Analyst** - Analyze & visualize data
17. **Finance Assistant** - Financial analysis & planning
18. **Learning Tutor** - Educational content & tutoring
19. **Project Manager** - Task & project management
20. **Automation Expert** - Build workflows & automations
21. **Prompt Engineer** - Optimize LLM prompts
22. **Resume Builder** - Create professional resumes

## 🔐 Security

- RBAC (Role-Based Access Control)
- API key encryption
- Rate limiting
- Input validation
- Secure secrets storage
- Audit logging
- CORS protection

## 📄 License

MIT License - see LICENSE file for details

## 🙋 Support

- GitHub Issues: [Report bugs](https://github.com/yourusername/WelvoxAgent/issues)
- Documentation: Check `docs/` folder
- Email: support@welvoxai.com

## 🎉 Acknowledgments

Built with:
- FastAPI - Modern async Python web framework
- Next.js - React framework for production
- LangGraph - Multi-agent orchestration
- Anthropic Claude - Best-in-class LLM
- Qdrant - Vector database

---

**Version**: 1.0.0  
**Last Updated**: January 2024  
**Maintainers**: Piyush Joshi & Team

**Happy building! 🚀**
