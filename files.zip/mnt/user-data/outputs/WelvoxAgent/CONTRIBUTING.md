# Contributing to WelvoxAgent

Thank you for your interest in contributing to WelvoxAgent! This document provides guidelines and instructions for contributing.

## Code of Conduct

- Be respectful and inclusive
- Provide constructive feedback
- Help others learn and grow
- Report issues responsibly
- No harassment or discrimination

## Getting Started

### 1. Fork & Clone

```bash
git clone https://github.com/yourusername/WelvoxAgent.git
cd WelvoxAgent
```

### 2. Create a Branch

```bash
git checkout -b feature/your-feature-name
```

Use descriptive branch names:
- `feature/` for new features
- `fix/` for bug fixes
- `docs/` for documentation
- `refactor/` for refactoring
- `test/` for tests

### 3. Install Dependencies

```bash
make install
```

### 4. Make Your Changes

```bash
# Start development servers
make dev

# In another terminal, run tests
make test-watch
```

## Development Workflow

### Code Style

**TypeScript/JavaScript:**
```bash
# Format code
pnpm format

# Lint
pnpm lint

# Type check
pnpm type-check
```

**Python:**
```bash
# Format with black
black apps/api/

# Lint with flake8
flake8 apps/api/

# Type check with mypy
mypy apps/api/
```

### Commit Messages

Follow conventional commits:

```
type(scope): description

[optional body]
[optional footer]
```

Examples:
- `feat(agents): add intent detection engine`
- `fix(skills): handle missing tool credentials`
- `docs(api): update endpoint documentation`
- `refactor(memory): optimize embedding search`
- `test(agents): add unit tests for orchestration`

### Pull Request Process

1. **Update your branch**
   ```bash
   git fetch origin
   git rebase origin/main
   ```

2. **Run full test suite**
   ```bash
   make test
   make lint
   make type-check
   ```

3. **Push your changes**
   ```bash
   git push origin feature/your-feature-name
   ```

4. **Create Pull Request**
   - Use descriptive title
   - Reference related issues (#123)
   - Describe changes and rationale
   - Add tests for new features
   - Update documentation

5. **Address Review Comments**
   - Make requested changes
   - Push new commits
   - Request re-review

## What to Contribute

### Good First Issues

Look for issues labeled `good-first-issue` or `help-wanted`.

### Areas Needing Help

- [ ] Default skills (22 total)
- [ ] Tool integrations (GitHub, Slack, etc.)
- [ ] UI components
- [ ] Documentation
- [ ] Tests
- [ ] Performance optimization
- [ ] Bug fixes

### Creating New Skills

See [SKILLS.md](./SKILLS.md) for detailed guide.

Quick checklist:
- [ ] Define input/output schemas
- [ ] Write prompt template
- [ ] Implement execute() method
- [ ] Add tests
- [ ] Document usage
- [ ] Register in skill registry

### Creating Tool Integrations

```python
# packages/integrations/my_tool.py

class MyToolIntegration:
    id = "my_tool"
    name = "My Tool"
    description = "Integration with My Tool"
    
    async def authenticate(self, credentials: dict):
        """Handle authentication"""
        pass
    
    async def execute(self, action: str, params: dict):
        """Execute tool action"""
        pass
    
    async def list_actions(self):
        """List available actions"""
        pass
```

## Testing

### Writing Tests

```python
# Test file: test_my_feature.py

import pytest

@pytest.fixture
def my_fixture():
    """Set up test data"""
    return {"data": "value"}

@pytest.mark.asyncio
async def test_my_feature(my_fixture):
    """Test description"""
    result = await my_feature(my_fixture)
    assert result == expected_value

@pytest.mark.parametrize("input,expected", [
    ("a", "A"),
    ("b", "B"),
])
def test_parametrized(input, expected):
    """Test with multiple inputs"""
    assert process(input) == expected
```

### Running Tests

```bash
# All tests
make test

# Watch mode
make test-watch

# With coverage
make test-coverage

# Specific test
pytest path/to/test.py::test_function -v
```

### Test Coverage

Aim for 80%+ coverage on new code.

```bash
make test-coverage
# View: htmlcov/index.html
```

## Documentation

### Update Documentation for:
- New features
- API changes
- Breaking changes
- Architecture changes

### Documentation Locations:
- `README.md` - Overview
- `ARCHITECTURE.md` - System design
- `API.md` - API reference
- `SKILLS.md` - Skill development
- `DEPLOYMENT.md` - Deployment guide
- `/docs` folder - Additional guides

### Documentation Style

- Clear and concise
- Use examples
- Include code snippets
- Add diagrams where helpful
- Keep current with code

## Common Tasks

### Adding a New Package

```bash
# Create directory
mkdir -p packages/my-package/src

# Create package.json
cat > packages/my-package/package.json << 'EOF'
{
  "name": "@welvox/my-package",
  "version": "1.0.0",
  "description": "Description",
  "main": "src/index.ts",
  "types": "src/index.ts",
  "scripts": {
    "build": "tsc",
    "test": "vitest"
  }
}
EOF

# Create TypeScript config
cat > packages/my-package/tsconfig.json << 'EOF'
{
  "extends": "../../tsconfig.json",
  "compilerOptions": {
    "outDir": "./dist"
  },
  "include": ["src"]
}
EOF
```

### Adding a New API Endpoint

```python
# routers/my_feature.py

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/my-feature", tags=["my-feature"])

class MyRequest(BaseModel):
    data: str

class MyResponse(BaseModel):
    result: str

@router.post("/action", response_model=MyResponse)
async def my_action(request: MyRequest):
    """Description of endpoint"""
    try:
        # Implementation
        return MyResponse(result="...")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Then in main.py:
# app.include_router(my_feature.router)
```

## Debugging

### Debug Mode

```bash
# Set env var
export DEBUG=true

# Start with verbose logging
LOG_LEVEL=DEBUG make dev
```

### Browser DevTools

- Chrome DevTools for frontend
- Network tab for API requests
- Console for errors

### Python Debugging

```python
# Using pdb
import pdb
pdb.set_trace()

# Using print debugging
logger.debug(f"Value: {my_var}")

# Using VS Code debugger
# Add breakpoint and use debug launch configuration
```

## Performance

### Profiling

```python
# Python profiling
import cProfile
cProfile.run('my_function()')

# React profiling
# Use React DevTools Profiler
```

### Optimization Tips

- Use caching strategically
- Optimize database queries
- Minimize bundle size
- Lazy load components
- Use async operations

## Reporting Issues

### Before Creating Issue

- Check existing issues
- Search documentation
- Try to reproduce issue

### Creating Issue

```markdown
**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior.

**Expected behavior**
What you expected to happen.

**Screenshots**
If applicable, add screenshots.

**Environment:**
- OS: Windows/Mac/Linux
- Node version: X.X.X
- Python version: X.X.X
- Browser: Chrome/Firefox/Safari

**Additional context**
Any other context.
```

## Review Process

### What Reviewers Look For

- ✅ Code quality and style
- ✅ Test coverage
- ✅ Documentation
- ✅ No breaking changes
- ✅ Performance impact
- ✅ Security implications
- ✅ Backwards compatibility

### Code Review Tips

**As Author:**
- Keep PRs focused and small
- Respond to feedback promptly
- Ask questions if unclear
- Acknowledge good suggestions

**As Reviewer:**
- Be constructive and kind
- Suggest improvements
- Approve when ready
- Use "Request changes" sparingly

## Merging

Requirements:
- ✅ CI/CD passes
- ✅ At least 1 approval
- ✅ No requested changes
- ✅ Up to date with main

After merge:
- Branch is auto-deleted
- Changes are deployed
- Close related issues

## Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Thanked in releases
- Credited in documentation
- Invited to community

## Need Help?

- **Questions**: Open a discussion
- **Issues**: Create an issue with details
- **Chat**: Join our community Discord
- **Email**: support@welvoxai.com

---

Thank you for contributing to WelvoxAgent! 🚀
