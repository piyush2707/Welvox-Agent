# WelvoxAgent Architecture

## System Overview

WelvoxAgent is built on a **modular, event-driven architecture** that separates concerns into clear layers:

```
┌─────────────────────────────────────────────────────────────┐
│                    User Interface (Next.js)                 │
│          - Chat Interface, Task Dashboard, Settings         │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTP/WebSocket
┌────────────────────────▼────────────────────────────────────┐
│                 API Gateway (FastAPI)                       │
│    Authentication, Rate Limiting, Request Validation        │
└────────────────────────┬────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
┌───────▼─────┐  ┌──────▼──────┐  ┌─────▼──────────┐
│   Agents    │  │   Skills    │  │  Memory/Tools  │
│ Orchestr.  │  │   Registry  │  │   Integration  │
│ (LangGraph) │  │             │  │                │
└───────┬─────┘  └──────┬──────┘  └─────┬──────────┘
        │                │               │
        └────────────────┼───────────────┘
                         │
┌────────────┬───────────┼──────────┬──────────┐
│            │           │          │          │
▼            ▼           ▼          ▼          ▼
PostgreSQL  Redis     Qdrant   AI APIs   External Tools
Database    Cache     Vector   (Claude)  (GitHub, Slack)
            Queue     Search   (OpenAI)
```

## Core Components

### 1. **API Layer** (`apps/api`)

**FastAPI-based REST/WebSocket API**

- Request validation with Pydantic
- Authentication via Clerk
- Rate limiting & CORS
- Error handling & logging
- Streaming response support

**Key Routers:**
- `/api/agents/chat` - Main agent interaction
- `/api/skills/*` - Skill management
- `/api/memory/*` - Memory operations
- `/api/tools/*` - Tool integrations
- `/api/projects/*` - Project management

### 2. **Orchestration Engine** (`packages/agents`)

**LangGraph-powered multi-agent coordinator**

```python
# Workflow: Request → Intent → Plan → Execute → Response

class OrchestratorEngine:
    def __init__(self):
        self.intent_detector = IntentDetector()
        self.planner = TaskPlanner()
        self.executor = TaskExecutor()
        self.memory = MemoryManager()
    
    async def process_request(self, message: str, context: dict):
        # 1. Detect intent
        intent = await self.intent_detector.detect(message)
        
        # 2. Plan subtasks
        plan = await self.planner.create_plan(intent, context)
        
        # 3. Execute with skills
        results = await self.executor.execute_plan(plan)
        
        # 4. Compose response
        response = await self.compose_response(results)
        
        # 5. Store in memory
        await self.memory.store(message, response)
        
        return response
```

### 3. **Skill System** (`packages/skills`)

**Plugin-based skill architecture**

Each skill contains:
- **Metadata**: Name, description, category
- **Input Schema**: Pydantic model for inputs
- **Output Schema**: Expected output structure
- **Prompt Template**: LLM instructions
- **Tool Dependencies**: Required integrations
- **Permissions**: Access control

**Skill Lifecycle:**
```
Discover → Register → Validate → Execute → Cache
   ↓         ↓         ↓         ↓       ↓
Registry   Registry  Schema    Engine  Memory
```

### 4. **Memory System** (`packages/memory`)

**Multi-layer memory architecture**

```
┌─────────────────────────────────────────────┐
│         Semantic Memory (RAG)               │
│    - Entity relationships                   │
│    - Learned facts & patterns               │
│    - Vector embeddings in Qdrant            │
└─────────────────────────────────────────────┘
                    ▲
                    │ Store
                    │
┌─────────────────────────────────────────────┐
│       Conversation Memory (Short-term)      │
│    - Recent messages (Redis)                │
│    - Session context                       │
│    - Temporary facts                        │
└─────────────────────────────────────────────┘
                    ▲
                    │ Store
                    │
┌─────────────────────────────────────────────┐
│       Project Memory (Long-term)            │
│    - Project context (PostgreSQL)           │
│    - Decision history                       │
│    - Generated artifacts                    │
└─────────────────────────────────────────────┘
```

**Key Features:**
- **Semantic Search**: Find relevant past interactions
- **RAG Integration**: Augment LLM with retrieved context
- **User Preferences**: Learn and adapt to user style
- **Automatic Cleanup**: Expire old entries

### 5. **Tool Integration** (`packages/integrations`)

**Unified interface for external services**

```python
class ToolRouter:
    async def call_tool(self, tool_id: str, action: str, params: dict):
        # Route to appropriate integration
        tool = self.registry.get(tool_id)
        result = await tool.execute(action, params)
        return result

# Supported Tools:
# - GitHub: Repos, issues, PRs, workflows
# - Gmail: Send, read, search emails
# - Slack: Messages, channels, threads
# - Google Drive: Files, folders, permissions
# - Notion: Databases, pages, properties
# - Jira: Issues, boards, sprints
# - Stripe: Payments, customers, invoices
```

### 6. **Database Layer** (`packages/database`)

**PostgreSQL with SQLAlchemy ORM**

**Core Tables:**
```sql
-- Users & Projects
users (id, email, name, preferences)
projects (id, user_id, name, description, status)

-- Memory & Context
conversations (id, user_id, messages, created_at)
memory_entries (id, user_id, type, content, embedding)
project_context (id, project_id, data, metadata)

-- Tasks & Executions
tasks (id, project_id, title, status, assigned_skill)
executions (id, task_id, status, results, logs)

-- Tool Integrations
tool_credentials (id, user_id, tool_id, encrypted_token)
tool_calls (id, user_id, tool_id, action, params, result)

-- Auditing
audit_logs (id, user_id, action, resource, changes)
```

**Migrations:**
- Use Alembic for version control
- Run with: `pnpm db:migrate`

## Data Flow Example

**Scenario**: User asks "Build my startup website"

```
1. Request Received
   User: "Build my startup website"
   └─→ API validates & authenticates

2. Intent Detection
   Detected: {
     type: "generation",
     domain: "web_development",
     complexity: "high",
     required_skills: ["design", "coding", "deployment"]
   }

3. Task Planning
   Plan: [
     Task 1: "Gather design requirements",
     Task 2: "Generate UI mockups",
     Task 3: "Write frontend code",
     Task 4: "Create backend API",
     Task 5: "Deploy to cloud"
   ]

4. Skill Selection & Execution
   
   Task 1 → Research Skill
           └─→ Web search for design trends
   
   Task 2 → Design Skill
           └─→ Generate mockups with AI
   
   Task 3 → Coding Skill
           └─→ Generate React components
   
   Task 4 → Backend Skill
           └─→ Generate FastAPI endpoints
   
   Task 5 → DevOps Skill
           └─→ Create Docker configs
           └─→ Deploy via GitHub Actions

5. Result Composition
   └─→ Combine all artifacts
   └─→ Create project structure
   └─→ Generate README

6. Memory Storage
   └─→ Store in project memory
   └─→ Index in vector DB
   └─→ Track in audit logs

7. Response Delivery
   └─→ Stream results to frontend
   └─→ Show progress indicators
   └─→ Enable artifact downloads
```

## Performance Characteristics

### Latency
- Intent detection: ~100ms
- Task planning: ~200ms
- Skill execution: Variable (depends on skill)
- Memory operations: ~50ms

### Throughput
- Single instance: ~100 requests/second
- With Redis queue: Async job processing

### Scalability
- Horizontal: Add more API instances
- Vertical: Increase pod resources
- Database: PostgreSQL with read replicas
- Cache: Redis cluster

## Security Architecture

### Authentication
- Clerk OAuth integration
- JWT tokens with expiration
- Refresh token rotation

### Authorization
- RBAC (Role-Based Access Control)
- Permission checks at skill level
- Tool access requires explicit permission

### Data Protection
- Encryption at rest (PostgreSQL)
- Encryption in transit (TLS)
- Secrets in secure vault
- PII masking in logs

### Audit Trail
- All API calls logged
- Tool integrations audited
- Memory access tracked
- User actions recorded

## Deployment Topology

### Development
```
Docker Compose:
- PostgreSQL container
- Redis container
- Qdrant container
- FastAPI dev server
- Next.js dev server
```

### Production (Kubernetes)
```
- 3x API pods (FastAPI)
- 2x Web pods (Next.js)
- 1x PostgreSQL statefulset
- 1x Redis cache
- 1x Qdrant vector DB
- Nginx ingress
- Prometheus monitoring
- ELK logging
```

## Extension Points

### Adding a New Skill
1. Create skill definition in `packages/skills`
2. Implement prompt template
3. Define input/output schemas
4. Register in skill registry
5. Add tests

### Adding a Tool Integration
1. Create integration in `packages/integrations`
2. Implement authentication
3. Create wrapper methods for each action
4. Add to tool router
5. Document usage

### Customizing Memory
1. Extend MemoryManager
2. Implement custom storage strategy
3. Add retrieval logic
4. Test with RAG pipeline

## Monitoring & Observability

**Metrics Tracked:**
- Request latency (by endpoint)
- Error rates (by type)
- Token usage (by model)
- Skill success rate
- Memory hit rate
- Tool integration status

**Logging:**
- Structured JSON logs
- ELK stack integration
- Log levels: DEBUG, INFO, WARNING, ERROR
- Correlation IDs for tracing

**Alerts:**
- High error rate
- Service downtime
- Token quota near limit
- Database performance
- Memory issues

## Future Roadmap

- [ ] Multi-agent collaboration
- [ ] Custom model fine-tuning
- [ ] Graph databases for knowledge
- [ ] Real-time collaboration
- [ ] Voice input/output
- [ ] Mobile app
- [ ] Marketplace for skills
- [ ] Custom enterprise deployments

---

For more details, see individual package documentation.
