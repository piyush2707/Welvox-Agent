import type { Metadata } from 'next'
import { ClerkProvider } from '@clerk/nextjs'
import './globals.css'

export const metadata: Metadata = {
  title: 'WelvoxAgent - Universal AI Operating System',
  description: 'One AI. Infinite Skills.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ClerkProvider>
      <html lang="en" className="scroll-smooth">
        <body className="antialiased bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-50">
          {children}
        </body>
      </html>
    </ClerkProvider>
  )
}
