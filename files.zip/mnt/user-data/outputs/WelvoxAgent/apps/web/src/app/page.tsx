'use client'

import { useUser } from '@clerk/nextjs'
import Link from 'next/link'
import { ArrowRight, Zap, Brain, Shield } from 'lucide-react'

export default function Home() {
  const { user, isLoaded } = useUser()

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Welvox
          </div>
          <div className="flex items-center gap-4">
            {isLoaded && user ? (
              <Link
                href="/dashboard"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold transition"
              >
                Dashboard
              </Link>
            ) : (
              <Link
                href="/sign-in"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold transition"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="pt-32 px-4 max-w-7xl mx-auto text-center">
        <div className="space-y-6">
          <h1 className="text-6xl font-bold text-white">
            One AI. <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Infinite Skills.
            </span>
          </h1>
          
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            WelvoxAgent is a Universal AI Operating System that understands any request,
            breaks it into subtasks, and executes with the perfect combination of AI skills and tools.
          </p>

          <div className="flex gap-4 justify-center pt-8">
            <Link
              href="/sign-up"
              className="px-8 py-4 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold flex items-center gap-2 transition transform hover:scale-105"
            >
              Get Started <ArrowRight size={20} />
            </Link>
            <Link
              href="/docs"
              className="px-8 py-4 bg-slate-800 hover:bg-slate-700 rounded-lg font-semibold transition"
            >
              Documentation
            </Link>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mt-24">
          {[
            {
              icon: Brain,
              title: 'Intelligent Orchestration',
              description: 'Automatically understands intent and routes to appropriate AI skills'
            },
            {
              icon: Zap,
              title: 'Multi-Skill System',
              description: '22 default AI skills covering coding, research, content, and more'
            },
            {
              icon: Shield,
              title: 'Enterprise Ready',
              description: 'Production-grade security, scaling, and compliance built-in'
            }
          ].map((feature, i) => (
            <div
              key={i}
              className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 hover:border-blue-500 transition"
            >
              <feature.icon className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-slate-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
