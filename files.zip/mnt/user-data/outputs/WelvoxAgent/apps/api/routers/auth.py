from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from core.config import settings

router = APIRouter()


class UserProfile(BaseModel):
    id: str
    email: str
    name: str
    avatar_url: str | None = None


@router.get("/me", response_model=UserProfile)
async def get_current_user(user_id: str = None):
    """Get current user profile"""
    if not user_id:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    return {
        "id": user_id,
        "email": f"user_{user_id}@example.com",
        "name": f"User {user_id}",
        "avatar_url": None
    }


@router.post("/login")
async def login(email: str, password: str):
    """User login (Clerk integration)"""
    return {
        "access_token": "mock_token",
        "token_type": "bearer"
    }


@router.post("/logout")
async def logout():
    """User logout"""
    return {"message": "Logged out successfully"}
