from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional

router = APIRouter()


class Project(BaseModel):
    id: str
    name: str
    description: str
    status: str  # "planning", "active", "completed"
    created_at: str
    updated_at: str
    tags: List[str] = []


class ProjectTask(BaseModel):
    id: str
    title: str
    description: str
    status: str  # "todo", "in_progress", "done"
    assigned_to: Optional[str] = None


@router.get("/", response_model=List[Project])
async def list_projects(user_id: str):
    """List user's projects"""
    return []


@router.post("/", response_model=Project)
async def create_project(
    name: str,
    description: str,
    user_id: str
):
    """Create new project"""
    return {
        "id": "new_project",
        "name": name,
        "description": description,
        "status": "planning",
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
        "tags": []
    }


@router.get("/{project_id}", response_model=Project)
async def get_project(project_id: str):
    """Get project details"""
    raise ValueError("Project not found")


@router.put("/{project_id}", response_model=Project)
async def update_project(project_id: str, name: str = None, description: str = None):
    """Update project"""
    return {
        "id": project_id,
        "name": name or "Project",
        "description": description or "",
        "status": "active",
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z"
    }


@router.delete("/{project_id}")
async def delete_project(project_id: str):
    """Delete project"""
    return {"deleted": True}


@router.get("/{project_id}/tasks", response_model=List[ProjectTask])
async def get_project_tasks(project_id: str):
    """Get project tasks"""
    return []


@router.post("/{project_id}/tasks", response_model=ProjectTask)
async def create_project_task(project_id: str, title: str, description: str):
    """Create task in project"""
    return {
        "id": "task_id",
        "title": title,
        "description": description,
        "status": "todo"
    }


@router.put("/{project_id}/tasks/{task_id}")
async def update_project_task(
    project_id: str,
    task_id: str,
    status: str = None
):
    """Update project task"""
    return {"task_id": task_id, "status": status or "in_progress"}
