// API Endpoints
export const API_ROUTES = {
  AUTH: {
    LOGIN: '/api/auth/login',
    LOGOUT: '/api/auth/logout',
    SIGNUP: '/api/auth/signup',
    REFRESH: '/api/auth/refresh',
    VERIFY: '/api/auth/verify',
  },
  CONVERSATIONS: {
    LIST: '/api/conversations',
    CREATE: '/api/conversations',
    GET: '/api/conversations/:id',
    UPDATE: '/api/conversations/:id',
    DELETE: '/api/conversations/:id',
    SEND_MESSAGE: '/api/conversations/:id/messages',
    GET_MESSAGES: '/api/conversations/:id/messages',
  },
  PROJECTS: {
    LIST: '/api/projects',
    CREATE: '/api/projects',
    GET: '/api/projects/:id',
    UPDATE: '/api/projects/:id',
    DELETE: '/api/projects/:id',
  },
  TASKS: {
    LIST: '/api/tasks',
    CREATE: '/api/tasks',
    GET: '/api/tasks/:id',
    UPDATE: '/api/tasks/:id',
    DELETE: '/api/tasks/:id',
  },
  SKILLS: {
    LIST: '/api/skills',
    GET: '/api/skills/:id',
    EXECUTE: '/api/skills/:id/execute',
  },
  AGENTS: {
    LIST: '/api/agents',
    GET: '/api/agents/:id',
    CREATE: '/api/agents',
  },
  MEMORY: {
    LIST: '/api/memory',
    CREATE: '/api/memory',
    SEARCH: '/api/memory/search',
    DELETE: '/api/memory/:id',
  },
  FILES: {
    UPLOAD: '/api/files/upload',
    DOWNLOAD: '/api/files/:id/download',
    DELETE: '/api/files/:id',
    ANALYZE: '/api/files/:id/analyze',
  },
  USER: {
    PROFILE: '/api/user/profile',
    SETTINGS: '/api/user/settings',
    API_KEYS: '/api/user/api-keys',
  },
} as const;

// WebSocket Events
export const WS_EVENTS = {
  CONNECT: 'connect',
  DISCONNECT: 'disconnect',
  MESSAGE_RECEIVED: 'message:received',
  MESSAGE_SENT: 'message:sent',
  TYPING: 'typing',
  AGENT_THINKING: 'agent:thinking',
  AGENT_TOOL_CALL: 'agent:tool_call',
  AGENT_RESPONSE: 'agent:response',
  TASK_PROGRESS: 'task:progress',
  ERROR: 'error',
} as const;

// Error Codes
export const ERROR_CODES = {
  INVALID_REQUEST: 'INVALID_REQUEST',
  UNAUTHORIZED: 'UNAUTHORIZED',
  FORBIDDEN: 'FORBIDDEN',
  NOT_FOUND: 'NOT_FOUND',
  CONFLICT: 'CONFLICT',
  RATE_LIMITED: 'RATE_LIMITED',
  SERVER_ERROR: 'SERVER_ERROR',
  SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  AUTHENTICATION_FAILED: 'AUTHENTICATION_FAILED',
  PERMISSION_DENIED: 'PERMISSION_DENIED',
} as const;

// Status Codes
export const STATUS_CODES = {
  OK: 200,
  CREATED: 201,
  ACCEPTED: 202,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  RATE_LIMITED: 429,
  INTERNAL_SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503,
} as const;

// Skill Categories & Tags
export const SKILL_CATEGORIES = [
  'assistant',
  'coding',
  'research',
  'content',
  'data',
  'file',
  'communication',
  'analytics',
  'planning',
  'automation',
] as const;

export const SKILL_TAGS = [
  'ai',
  'automation',
  'productivity',
  'analysis',
  'creative',
  'technical',
  'business',
  'writing',
  'coding',
  'research',
  'planning',
  'communication',
] as const;

// AI Models
export const AI_MODELS = {
  CLAUDE: {
    'claude-opus-4-1': 'Claude Opus 4.1',
    'claude-sonnet-4-1': 'Claude Sonnet 4.1',
    'claude-haiku-3-5': 'Claude Haiku 3.5',
  },
  OPENAI: {
    'gpt-4': 'GPT-4',
    'gpt-4-turbo': 'GPT-4 Turbo',
    'gpt-3.5-turbo': 'GPT-3.5 Turbo',
  },
  GOOGLE: {
    'gemini-pro': 'Gemini Pro',
    'gemini-pro-vision': 'Gemini Pro Vision',
  },
  OPENROUTER: {
    'meta-llama/llama-2-70b': 'Llama 2 70B',
    'mistralai/mistral-large': 'Mistral Large',
  },
} as const;

// Pagination
export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 20,
  MAX_PAGE_SIZE: 100,
  MIN_PAGE_SIZE: 1,
} as const;

// File Limits
export const FILE_LIMITS = {
  MAX_FILE_SIZE: 50 * 1024 * 1024, // 50MB
  MAX_FILES_PER_UPLOAD: 10,
  ALLOWED_TYPES: [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/csv',
    'application/json',
    'text/plain',
    'text/markdown',
    'image/jpeg',
    'image/png',
    'image/gif',
  ],
} as const;

// Rate Limits
export const RATE_LIMITS = {
  API: {
    requestsPerMinute: 60,
    requestsPerHour: 1000,
    requestsPerDay: 10000,
  },
  SKILLS: {
    requestsPerMinute: 30,
    requestsPerHour: 500,
  },
  FILES: {
    uploadPerHour: 50,
  },
} as const;

// Feature Flags
export const FEATURES = {
  VOICE_CHAT: true,
  VIDEO_CHAT: false,
  PLUGINS: true,
  CUSTOM_AGENTS: true,
  TEAM_COLLABORATION: false,
  ADVANCED_ANALYTICS: false,
} as const;
