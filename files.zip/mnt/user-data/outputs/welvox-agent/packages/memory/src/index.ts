import type { Memory, MemoryType } from '@welvox/types';

export interface MemoryStoreOptions {
  maxShortTermMemories: number;
  shortTermTTL: number; // milliseconds
  vectorDimension: number;
  similarityThreshold: number;
}

export class MemoryManager {
  private shortTermMemories: Map<string, Memory> = new Map();
  private options: MemoryStoreOptions = {
    maxShortTermMemories: 100,
    shortTermTTL: 24 * 60 * 60 * 1000, // 24 hours
    vectorDimension: 1536,
    similarityThreshold: 0.7,
  };

  constructor(options?: Partial<MemoryStoreOptions>) {
    this.options = { ...this.options, ...options };
  }

  // Store memory
  async storeMemory(
    userId: string,
    type: MemoryType,
    content: string,
    embedding?: number[],
    metadata?: Record<string, unknown>
  ): Promise<Memory> {
    const memory: Memory = {
      id: this.generateId(),
      userId,
      type,
      content,
      embedding,
      metadata: {
        source: 'system',
        importance: 0.5,
        tags: [],
        relatedIds: [],
        ...metadata,
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Store short-term in memory, rest would go to database/Qdrant
    if (type === 'short_term') {
      this.shortTermMemories.set(memory.id, memory);
      this.cleanupShortTermMemories();
    }

    return memory;
  }

  // Retrieve memory by ID
  async getMemory(id: string): Promise<Memory | null> {
    return this.shortTermMemories.get(id) || null;
  }

  // Search memories semantically by embedding similarity
  async searchSemantic(query: number[], limit = 10): Promise<Memory[]> {
    const results: { memory: Memory; similarity: number }[] = [];

    for (const memory of this.shortTermMemories.values()) {
      if (memory.embedding) {
        const similarity = this.cosineSimilarity(query, memory.embedding);
        if (similarity >= this.options.similarityThreshold) {
          results.push({ memory, similarity });
        }
      }
    }

    return results
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit)
      .map((r) => r.memory);
  }

  // Get memories by type
  async getMemoriesByType(userId: string, type: MemoryType, limit = 20): Promise<Memory[]> {
    return Array.from(this.shortTermMemories.values())
      .filter((m) => m.userId === userId && m.type === type)
      .sort((a, b) => b.importance - a.importance)
      .slice(0, limit);

    function get importance(): number {
      return 0;
    }
  }

  // Update memory importance
  async updateMemoryImportance(id: string, importance: number): Promise<Memory | null> {
    const memory = this.shortTermMemories.get(id);
    if (!memory) return null;

    memory.metadata.importance = Math.min(1, Math.max(0, importance));
    memory.updatedAt = new Date();
    this.shortTermMemories.set(id, memory);

    return memory;
  }

  // Delete memory
  async deleteMemory(id: string): Promise<boolean> {
    return this.shortTermMemories.delete(id);
  }

  // Cleanup expired short-term memories
  private cleanupShortTermMemories(): void {
    const now = Date.now();
    const expired: string[] = [];

    for (const [id, memory] of this.shortTermMemories) {
      if (now - memory.createdAt.getTime() > this.options.shortTermTTL) {
        expired.push(id);
      }
    }

    for (const id of expired) {
      this.shortTermMemories.delete(id);
    }

    // If still over limit, remove least important
    if (this.shortTermMemories.size > this.options.maxShortTermMemories) {
      const sorted = Array.from(this.shortTermMemories.values()).sort(
        (a, b) => a.metadata.importance - b.metadata.importance
      );

      const toRemove = sorted.slice(0, sorted.length - this.options.maxShortTermMemories);
      for (const memory of toRemove) {
        this.shortTermMemories.delete(memory.id);
      }
    }
  }

  // Get context for conversation
  async getContextMemories(userId: string, limit = 5): Promise<Memory[]> {
    const shortTerm = await this.getMemoriesByType(userId, 'short_term', limit);
    return shortTerm;
  }

  // Cosine similarity between vectors
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) return 0;

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  // Generate unique ID
  private generateId(): string {
    return `mem_${Date.now()}_${Math.random().toString(36).substring(7)}`;
  }

  // Get all memories for user
  async listUserMemories(userId: string, type?: MemoryType): Promise<Memory[]> {
    let memories = Array.from(this.shortTermMemories.values()).filter((m) => m.userId === userId);

    if (type) {
      memories = memories.filter((m) => m.type === type);
    }

    return memories.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Clear all memories for user (careful!)
  async clearUserMemories(userId: string): Promise<number> {
    let count = 0;
    for (const [id, memory] of this.shortTermMemories) {
      if (memory.userId === userId) {
        this.shortTermMemories.delete(id);
        count++;
      }
    }
    return count;
  }
}

// Singleton instance
export const memoryManager = new MemoryManager();

// Export types
export type { MemoryStoreOptions };
