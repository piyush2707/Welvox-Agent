export * from './orchestrator';
export * from './executor';
export * from './router';

// Agent configuration
export const AGENT_CONFIG = {
  maxConcurrentTasks: 5,
  taskTimeout: 300000, // 5 minutes
  maxRetries: 3,
  retryDelay: 1000,
  enableCaching: true,
  cacheTTL: 3600, // 1 hour
};

// Agent types
export type AgentRole = 'orchestrator' | 'executor' | 'router' | 'memory' | 'reflector';

export interface AgentState {
  conversationId: string;
  userId: string;
  currentIntent: string;
  executionPlan?: any;
  memories: any[];
  artifacts: any[];
  errors: string[];
  completedTasks: number;
  startTime: Date;
}

export function createAgentState(conversationId: string, userId: string): AgentState {
  return {
    conversationId,
    userId,
    currentIntent: '',
    memories: [],
    artifacts: [],
    errors: [],
    completedTasks: 0,
    startTime: new Date(),
  };
}
