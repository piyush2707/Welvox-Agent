import type { User } from '@welvox/types';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';

export interface JWTPayload {
  sub: string;
  email: string;
  clerkId: string;
  iat: number;
  exp: number;
}

export interface PermissionSet {
  canRead: string[];
  canWrite: string[];
  canDelete: string[];
  canExecute: string[];
}

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const JWT_EXPIRY = '24h';

export function generateJWT(user: User): string {
  const payload: JWTPayload = {
    sub: user.id,
    email: user.email,
    clerkId: user.clerkId,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 24 * 60 * 60, // 24 hours
  };

  return jwt.sign(payload, JWT_SECRET);
}

export function verifyJWT(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload;
  } catch {
    return null;
  }
}

export function hashApiKey(key: string): string {
  return crypto.createHash('sha256').update(key).digest('hex');
}

export function generateApiKey(): string {
  return `welvox_${crypto.randomBytes(32).toString('hex')}`;
}

export function getDefaultPermissions(role: 'user' | 'admin' | 'moderator'): PermissionSet {
  const basePermissions: PermissionSet = {
    canRead: [
      'conversations',
      'messages',
      'projects',
      'tasks',
      'artifacts',
      'memory',
      'profile',
    ],
    canWrite: ['conversations', 'projects', 'artifacts'],
    canDelete: [],
    canExecute: ['skills', 'agents'],
  };

  if (role === 'admin') {
    return {
      canRead: ['*'],
      canWrite: ['*'],
      canDelete: ['*'],
      canExecute: ['*'],
    };
  }

  if (role === 'moderator') {
    return {
      ...basePermissions,
      canDelete: ['conversations', 'messages'],
      canWrite: [...basePermissions.canWrite, 'users', 'skills'],
    };
  }

  return basePermissions;
}

export function canAccess(
  permissions: PermissionSet,
  resource: string,
  action: 'read' | 'write' | 'delete' | 'execute'
): boolean {
  const actionMap = {
    read: 'canRead',
    write: 'canWrite',
    delete: 'canDelete',
    execute: 'canExecute',
  };

  const allowedResources = permissions[actionMap[action]];
  return allowedResources.includes('*') || allowedResources.includes(resource);
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePassword(password: string): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

export const AUTH_CONFIG = {
  JWT_EXPIRY,
  JWT_SECRET,
  API_KEY_PREFIX: 'welvox_',
  SESSION_TIMEOUT: 24 * 60 * 60 * 1000, // 24 hours in milliseconds
};
