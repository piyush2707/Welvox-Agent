import type { Skill, SkillCategory } from '@welvox/types';
import { getSkillPrompt } from '@welvox/prompts';

export interface SkillRegistry {
  skills: Map<string, Skill>;
  register(skill: Skill): void;
  get(id: string): Skill | undefined;
  list(category?: SkillCategory): Skill[];
  findByName(name: string): Skill | undefined;
}

export const createSkillRegistry = (): SkillRegistry => {
  const skills = new Map<string, Skill>();

  return {
    skills,
    register(skill: Skill) {
      skills.set(skill.id, skill);
    },
    get(id: string) {
      return skills.get(id);
    },
    list(category?: SkillCategory) {
      const list = Array.from(skills.values());
      return category ? list.filter((s) => s.category === category) : list;
    },
    findByName(name: string) {
      return Array.from(skills.values()).find((s) => s.name.toLowerCase() === name.toLowerCase());
    },
  };
};

// Default Skills
export const DEFAULT_SKILLS: Record<string, Skill> = {
  UNIVERSAL_ASSISTANT: {
    id: 'skill_universal_assistant',
    name: 'Universal Assistant',
    description: 'Helpful assistant for general questions and tasks',
    category: 'assistant',
    icon: '🤖',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['general', 'helpful', 'assistant'],
      inputSchema: { query: 'string' },
      outputSchema: { response: 'string' },
      requiredTools: [],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Answer Question',
        template: getSkillPrompt('UNIVERSAL_ASSISTANT'),
        variables: {},
      },
    ],
    tools: [],
    permissions: [
      { resource: 'conversations', action: 'read' },
      { resource: 'conversations', action: 'write' },
    ],
  },

  CODING_EXPERT: {
    id: 'skill_coding_expert',
    name: 'Coding Expert',
    description: 'Generate production-ready code with full explanations',
    category: 'coding',
    icon: '💻',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['code', 'programming', 'development', 'typescript', 'python'],
      inputSchema: {
        language: 'string',
        requirements: 'string',
        style: 'string',
      },
      outputSchema: { code: 'string', explanation: 'string' },
      requiredTools: ['code_executor'],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Generate Code',
        template: getSkillPrompt('CODE_GENERATOR'),
        variables: { language: 'typescript', style: 'clean' },
      },
    ],
    tools: [
      {
        id: 'code_executor',
        name: 'Code Executor',
        description: 'Execute and test code',
        function: 'execute_code',
        parameters: { code: 'string', language: 'string' },
      },
    ],
    permissions: [
      { resource: 'artifacts', action: 'write' },
      { resource: 'projects', action: 'read' },
    ],
  },

  RESEARCH_AGENT: {
    id: 'skill_research_agent',
    name: 'Research Agent',
    description: 'Conduct thorough research with citations and insights',
    category: 'research',
    icon: '🔍',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['research', 'analysis', 'learning', 'insights'],
      inputSchema: { topic: 'string', scope: 'string', depth: 'string' },
      outputSchema: {
        findings: 'string',
        sources: 'array',
        insights: 'array',
      },
      requiredTools: ['web_search', 'content_analysis'],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Research Topic',
        template: getSkillPrompt('RESEARCH_ASSISTANT'),
        variables: { depth: 'detailed' },
      },
    ],
    tools: [
      {
        id: 'web_search',
        name: 'Web Search',
        description: 'Search the web for information',
        function: 'search_web',
        parameters: { query: 'string', limit: 'number' },
      },
      {
        id: 'content_analysis',
        name: 'Content Analysis',
        description: 'Analyze and summarize content',
        function: 'analyze_content',
        parameters: { url: 'string' },
      },
    ],
    permissions: [
      { resource: 'memory', action: 'write' },
      { resource: 'artifacts', action: 'write' },
    ],
  },

  CONTENT_CREATOR: {
    id: 'skill_content_creator',
    name: 'Content Creator',
    description: 'Create engaging content for blogs, social media, and more',
    category: 'content',
    icon: '✍️',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['content', 'writing', 'social', 'marketing', 'creative'],
      inputSchema: {
        platform: 'string',
        topic: 'string',
        audience: 'string',
        style: 'string',
      },
      outputSchema: { content: 'string', suggestions: 'array' },
      requiredTools: [],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Generate Content',
        template: getSkillPrompt('CONTENT_GENERATOR'),
        variables: { style: 'engaging' },
      },
    ],
    tools: [],
    permissions: [
      { resource: 'artifacts', action: 'write' },
      { resource: 'projects', action: 'read' },
    ],
  },

  FILE_ANALYZER: {
    id: 'skill_file_analyzer',
    name: 'File Analyzer',
    description: 'Analyze and extract information from files',
    category: 'file',
    icon: '📄',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['files', 'analysis', 'extraction', 'pdf', 'documents'],
      inputSchema: { fileId: 'string', task: 'string' },
      outputSchema: { content: 'string', metadata: 'object' },
      requiredTools: ['file_parser', 'content_extractor'],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Analyze File',
        template: getSkillPrompt('FILE_EXTRACTOR'),
        variables: {},
      },
    ],
    tools: [
      {
        id: 'file_parser',
        name: 'File Parser',
        description: 'Parse various file formats',
        function: 'parse_file',
        parameters: { fileId: 'string', format: 'string' },
      },
      {
        id: 'content_extractor',
        name: 'Content Extractor',
        description: 'Extract specific content from files',
        function: 'extract_content',
        parameters: { fileId: 'string', query: 'string' },
      },
    ],
    permissions: [
      { resource: 'files', action: 'read' },
      { resource: 'artifacts', action: 'write' },
    ],
  },

  DATA_ANALYST: {
    id: 'skill_data_analyst',
    name: 'Data Analyst',
    description: 'Analyze data and create insights',
    category: 'data',
    icon: '📊',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['data', 'analysis', 'visualization', 'statistics', 'insights'],
      inputSchema: { data: 'string', analysisType: 'string' },
      outputSchema: { insights: 'array', visualizations: 'array' },
      requiredTools: ['data_processor', 'chart_generator'],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Analyze Data',
        template: getSkillPrompt('DATA_ANALYZER'),
        variables: { analysisType: 'statistical' },
      },
    ],
    tools: [
      {
        id: 'data_processor',
        name: 'Data Processor',
        description: 'Process and clean data',
        function: 'process_data',
        parameters: { data: 'string' },
      },
      {
        id: 'chart_generator',
        name: 'Chart Generator',
        description: 'Generate charts and visualizations',
        function: 'generate_chart',
        parameters: { data: 'string', chartType: 'string' },
      },
    ],
    permissions: [
      { resource: 'files', action: 'read' },
      { resource: 'artifacts', action: 'write' },
    ],
  },

  EMAIL_WRITER: {
    id: 'skill_email_writer',
    name: 'Email Writer',
    description: 'Write professional and engaging emails',
    category: 'communication',
    icon: '✉️',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['email', 'communication', 'professional', 'writing'],
      inputSchema: {
        purpose: 'string',
        recipient: 'string',
        tone: 'string',
      },
      outputSchema: { subject: 'string', body: 'string' },
      requiredTools: [],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Write Email',
        template: getSkillPrompt('EMAIL_WRITER'),
        variables: { tone: 'professional' },
      },
    ],
    tools: [],
    permissions: [
      { resource: 'artifacts', action: 'write' },
      { resource: 'communication', action: 'read' },
    ],
  },

  PROJECT_PLANNER: {
    id: 'skill_project_planner',
    name: 'Project Planner',
    description: 'Plan projects and create detailed task breakdowns',
    category: 'planning',
    icon: '📋',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['planning', 'project', 'tasks', 'management'],
      inputSchema: { projectName: 'string', goals: 'string' },
      outputSchema: { tasks: 'array', timeline: 'object' },
      requiredTools: [],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Plan Project',
        template: 'Create a detailed project plan for: {{projectName}}',
        variables: {},
      },
    ],
    tools: [],
    permissions: [
      { resource: 'projects', action: 'write' },
      { resource: 'tasks', action: 'write' },
    ],
  },

  AUTOMATION_EXPERT: {
    id: 'skill_automation_expert',
    name: 'Automation Expert',
    description: 'Design and implement workflow automation',
    category: 'automation',
    icon: '⚙️',
    version: '1.0.0',
    enabled: true,
    metadata: {
      author: 'Welvox AI',
      license: 'MIT',
      tags: ['automation', 'workflows', 'integration', 'efficiency'],
      inputSchema: { task: 'string', tools: 'array' },
      outputSchema: { workflow: 'object', documentation: 'string' },
      requiredTools: ['workflow_builder'],
    },
    prompts: [
      {
        id: 'prompt_1',
        name: 'Design Automation',
        template: 'Design automation for: {{task}}',
        variables: {},
      },
    ],
    tools: [
      {
        id: 'workflow_builder',
        name: 'Workflow Builder',
        description: 'Build automated workflows',
        function: 'build_workflow',
        parameters: { steps: 'array', triggers: 'array' },
      },
    ],
    permissions: [
      { resource: 'workflows', action: 'write' },
      { resource: 'integrations', action: 'read' },
    ],
  },
};

export function getDefaultSkill(name: string): Skill | undefined {
  return DEFAULT_SKILLS[name.toUpperCase().replace(/\s+/g, '_')];
}

export function getAllDefaultSkills(): Skill[] {
  return Object.values(DEFAULT_SKILLS);
}

export function categorizeSkills(skills: Skill[]): Record<SkillCategory, Skill[]> {
  const categories: Record<SkillCategory, Skill[]> = {
    assistant: [],
    coding: [],
    research: [],
    content: [],
    data: [],
    file: [],
    communication: [],
    analytics: [],
    planning: [],
    automation: [],
  };

  for (const skill of skills) {
    categories[skill.category].push(skill);
  }

  return categories;
}
