export * from './models';
export * from './migrations';
export * from './queries';

// Database connection utilities
export const DATABASE_CONFIG = {
  pool_size: 10,
  max_overflow: 20,
  echo: false,
  pool_pre_ping: true,
};

export async function initializeDatabase(databaseUrl: string) {
  // This would be called from the FastAPI backend to set up the database
  console.log('Initializing database with URL:', databaseUrl);
}
