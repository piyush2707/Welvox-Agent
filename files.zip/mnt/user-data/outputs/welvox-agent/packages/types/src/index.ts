// User & Auth
export interface User {
  id: string;
  clerkId: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: Date;
  updatedAt: Date;
  settings: UserSettings;
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'auto';
  language: string;
  aiProvider: 'claude' | 'openai' | 'gemini' | 'openrouter';
  defaultModel: string;
  autoSaveInterval: number;
}

// Skills
export interface Skill {
  id: string;
  name: string;
  description: string;
  category: SkillCategory;
  icon: string;
  version: string;
  enabled: boolean;
  metadata: SkillMetadata;
  prompts: SkillPrompt[];
  tools: SkillTool[];
  permissions: SkillPermission[];
}

export type SkillCategory =
  | 'assistant'
  | 'coding'
  | 'research'
  | 'content'
  | 'data'
  | 'file'
  | 'communication'
  | 'analytics'
  | 'planning'
  | 'automation';

export interface SkillMetadata {
  author: string;
  license: string;
  tags: string[];
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown>;
  requiredTools: string[];
}

export interface SkillPrompt {
  id: string;
  name: string;
  template: string;
  variables: Record<string, unknown>;
}

export interface SkillTool {
  id: string;
  name: string;
  description: string;
  params: Record<string, unknown>;
}

export interface SkillPermission {
  resource: string;
  action: 'read' | 'write' | 'delete' | 'execute';
}

// Agents
export interface Agent {
  id: string;
  name: string;
  description: string;
  systemPrompt: string;
  skills: string[];
  tools: AgentTool[];
  model: string;
  temperature: number;
  maxTokens: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface AgentTool {
  id: string;
  name: string;
  description: string;
  function: string;
  parameters: Record<string, unknown>;
}

// Memory
export interface Memory {
  id: string;
  userId: string;
  type: MemoryType;
  content: string;
  embedding?: number[];
  metadata: MemoryMetadata;
  createdAt: Date;
  updatedAt: Date;
  expiresAt?: Date;
}

export type MemoryType = 'short_term' | 'long_term' | 'semantic' | 'project' | 'preference';

export interface MemoryMetadata {
  source: string;
  importance: number;
  tags: string[];
  relatedIds: string[];
}

// Conversations
export interface Conversation {
  id: string;
  userId: string;
  title: string;
  messages: Message[];
  agentId?: string;
  status: 'active' | 'archived' | 'deleted';
  createdAt: Date;
  updatedAt: Date;
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  files?: FileReference[];
  toolCalls?: ToolCall[];
  metadata: MessageMetadata;
  createdAt: Date;
}

export interface MessageMetadata {
  model: string;
  tokens: {
    input: number;
    output: number;
  };
  reasoning?: string;
  confidence?: number;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: unknown;
  error?: string;
}

// Files
export interface FileReference {
  id: string;
  name: string;
  mimeType: string;
  size: number;
  path: string;
  uploadedAt: Date;
}

export interface FileAnalysis {
  fileId: string;
  type: FileType;
  content: string;
  metadata: FileMetadata;
  extractedData?: unknown;
}

export type FileType =
  | 'pdf'
  | 'docx'
  | 'pptx'
  | 'xlsx'
  | 'csv'
  | 'json'
  | 'xml'
  | 'text'
  | 'markdown'
  | 'image'
  | 'audio'
  | 'video'
  | 'archive';

export interface FileMetadata {
  pageCount?: number;
  wordCount?: number;
  lang?: string;
  encoding?: string;
  resolution?: string;
}

// Tasks & Workflows
export interface Task {
  id: string;
  projectId: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: 'low' | 'medium' | 'high' | 'critical';
  assignedAgent?: string;
  dependencies: string[];
  dueDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'failed' | 'blocked';

export interface Project {
  id: string;
  userId: string;
  name: string;
  description: string;
  status: ProjectStatus;
  tasks: Task[];
  memory: Memory[];
  artifacts: Artifact[];
  createdAt: Date;
  updatedAt: Date;
}

export type ProjectStatus = 'planning' | 'active' | 'completed' | 'archived';

// Artifacts
export interface Artifact {
  id: string;
  projectId: string;
  type: ArtifactType;
  title: string;
  content: string;
  metadata: ArtifactMetadata;
  createdAt: Date;
  updatedAt: Date;
}

export type ArtifactType =
  | 'code'
  | 'document'
  | 'presentation'
  | 'spreadsheet'
  | 'design'
  | 'diagram'
  | 'markdown'
  | 'plan'
  | 'other';

export interface ArtifactMetadata {
  language?: string;
  framework?: string;
  tags: string[];
  version: number;
}

// API Responses
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: ApiError;
  meta?: ResponseMeta;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export interface ResponseMeta {
  timestamp: Date;
  requestId: string;
  duration: number;
}

// Workflow & Orchestration
export interface WorkflowStep {
  id: string;
  name: string;
  action: string;
  inputs: Record<string, unknown>;
  outputs: Record<string, unknown>;
  status: 'pending' | 'running' | 'completed' | 'failed';
  agentId?: string;
}

export interface WorkflowExecution {
  id: string;
  workflowId: string;
  userId: string;
  steps: WorkflowStep[];
  status: 'pending' | 'running' | 'completed' | 'failed';
  startedAt: Date;
  completedAt?: Date;
  error?: string;
}

// Intent & Planning
export interface IntentDetection {
  intent: string;
  confidence: number;
  suggestedSkills: string[];
  requiredTools: string[];
  executionPlan: ExecutionPlan;
}

export interface ExecutionPlan {
  steps: PlanStep[];
  estimatedDuration: number;
  requiredResources: string[];
}

export interface PlanStep {
  id: string;
  name: string;
  description: string;
  skill: string;
  tools: string[];
  inputs: Record<string, unknown>;
  expectedOutputs: string[];
  dependencies: string[];
}

// Integration Events
export interface IntegrationEvent {
  id: string;
  type: string;
  source: string;
  payload: Record<string, unknown>;
  timestamp: Date;
  processed: boolean;
}

// Settings & Configuration
export interface SystemConfig {
  maintenance: boolean;
  maxConcurrentTasks: number;
  maxFileSize: number;
  taskTimeout: number;
  memoryRetentionDays: number;
  vectorSearchLimit: number;
}

export interface RateLimitConfig {
  requestsPerMinute: number;
  requestsPerHour: number;
  requestsPerDay: number;
}
