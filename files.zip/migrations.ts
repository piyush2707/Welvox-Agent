// Database migrations
// Managed via Alembic in the FastAPI backend
// This file documents the migration strategy

export const MIGRATIONS = {
  '001_initial_schema': {
    description: 'Create initial user, conversation, message tables',
    tables: ['users', 'conversations', 'messages'],
  },
  '002_add_projects': {
    description: 'Add projects and tasks tables',
    tables: ['projects', 'tasks'],
  },
  '003_add_skills': {
    description: 'Add skills and skill metadata',
    tables: ['skills'],
  },
  '004_add_memory': {
    description: 'Add memory and vector embedding support',
    tables: ['memories'],
    extensions: ['vector'],
  },
  '005_add_artifacts': {
    description: 'Add artifacts and file storage',
    tables: ['artifacts', 'file_references'],
  },
  '006_add_api_keys': {
    description: 'Add API key management',
    tables: ['api_keys'],
  },
  '007_add_audit_logs': {
    description: 'Add audit logging',
    tables: ['audit_logs'],
  },
};

export function getMigrationSQL(version: string): string {
  // This would return the SQL for each migration
  // Managed by Alembic tool
  return '';
}
