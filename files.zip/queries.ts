import type { User, Conversation, Message, Project, Memory } from '@welvox/types';

// Query helper interfaces for type-safe database operations
export interface QueryOptions {
  limit?: number;
  offset?: number;
  orderBy?: string;
  descending?: boolean;
}

export interface FilterOptions {
  [key: string]: unknown;
}

// User queries
export interface UserQueries {
  getById(id: string): Promise<User | null>;
  getByClerkId(clerkId: string): Promise<User | null>;
  getByEmail(email: string): Promise<User | null>;
  create(user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<User>;
  update(id: string, data: Partial<User>): Promise<User>;
  delete(id: string): Promise<boolean>;
}

// Conversation queries
export interface ConversationQueries {
  getById(id: string): Promise<Conversation | null>;
  listByUser(userId: string, options?: QueryOptions): Promise<Conversation[]>;
  create(conversation: Omit<Conversation, 'id' | 'createdAt' | 'updatedAt'>): Promise<Conversation>;
  update(id: string, data: Partial<Conversation>): Promise<Conversation>;
  delete(id: string): Promise<boolean>;
}

// Message queries
export interface MessageQueries {
  getById(id: string): Promise<Message | null>;
  listByConversation(
    conversationId: string,
    options?: QueryOptions
  ): Promise<Message[]>;
  create(message: Omit<Message, 'id' | 'createdAt'>): Promise<Message>;
  update(id: string, data: Partial<Message>): Promise<Message>;
}

// Memory queries
export interface MemoryQueries {
  getById(id: string): Promise<Memory | null>;
  listByUser(userId: string, type?: string, options?: QueryOptions): Promise<Memory[]>;
  create(memory: Omit<Memory, 'id' | 'createdAt' | 'updatedAt'>): Promise<Memory>;
  update(id: string, data: Partial<Memory>): Promise<Memory>;
  delete(id: string): Promise<boolean>;
  searchSemantic(embedding: number[], limit?: number): Promise<Memory[]>;
}

// Project queries
export interface ProjectQueries {
  getById(id: string): Promise<Project | null>;
  listByUser(userId: string, options?: QueryOptions): Promise<Project[]>;
  create(project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>): Promise<Project>;
  update(id: string, data: Partial<Project>): Promise<Project>;
  delete(id: string): Promise<boolean>;
}

// Pagination helper
export function buildPaginationQuery(
  options?: QueryOptions
): { limit: number; offset: number; orderBy?: string } {
  return {
    limit: options?.limit || 20,
    offset: options?.offset || 0,
    orderBy: options?.orderBy,
  };
}

// Filter builder
export function buildWhereClause(filters: FilterOptions): string {
  const conditions = Object.entries(filters)
    .filter(([, value]) => value !== undefined)
    .map(([key, value]) => {
      if (value === null) return `${key} IS NULL`;
      if (typeof value === 'string') return `${key} = '${value}'`;
      return `${key} = ${value}`;
    });

  return conditions.length > 0 ? ` WHERE ${conditions.join(' AND ')}` : '';
}
