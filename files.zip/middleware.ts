import { verifyJWT } from './index';

export interface AuthContext {
  userId: string;
  email: string;
  clerkId: string;
}

export function extractToken(authHeader: string | undefined): string | null {
  if (!authHeader) return null;
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') return null;
  return parts[1];
}

export function requireAuth(token: string | undefined): AuthContext {
  const extractedToken = extractToken(`Bearer ${token}`);
  if (!extractedToken) {
    throw new Error('Missing authentication token');
  }

  const payload = verifyJWT(extractedToken);
  if (!payload) {
    throw new Error('Invalid or expired token');
  }

  return {
    userId: payload.sub,
    email: payload.email,
    clerkId: payload.clerkId,
  };
}

export function requireRole(
  token: string | undefined,
  requiredRole: string
): AuthContext {
  const auth = requireAuth(token);
  // Role would be loaded from database or Clerk
  // This is a placeholder for the pattern
  return auth;
}

export function isValidOrigin(origin: string, allowedOrigins: string[]): boolean {
  return allowedOrigins.includes(origin) || allowedOrigins.includes('*');
}

export const CORS_CONFIG = {
  allowedOrigins: [
    'http://localhost:3000',
    'http://localhost:8000',
    'https://welvox.ai',
  ],
  allowedMethods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
  credentials: true,
};

export function buildCORSHeaders(origin: string | undefined) {
  if (!origin || !isValidOrigin(origin, CORS_CONFIG.allowedOrigins)) {
    return {};
  }

  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': CORS_CONFIG.allowedMethods.join(', '),
    'Access-Control-Allow-Headers': CORS_CONFIG.allowedHeaders.join(', '),
    'Access-Control-Allow-Credentials': 'true',
  };
}
