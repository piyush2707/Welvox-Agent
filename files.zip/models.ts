import type {
  User,
  Conversation,
  Message,
  Project,
  Task,
  Skill,
  Memory,
  Artifact,
  FileReference,
} from '@welvox/types';

// SQLAlchemy-style ORM models (Python equivalent would be in the API)
// This TypeScript version documents the schema structure

export const MODELS = {
  User: {
    table: 'users',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      clerk_id: { type: 'VARCHAR(255)', unique: true, index: true },
      email: { type: 'VARCHAR(255)', unique: true, index: true },
      name: { type: 'VARCHAR(255)' },
      avatar: { type: 'TEXT', nullable: true },
      settings: { type: 'JSONB', default: '{}' },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      updated_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  Conversation: {
    table: 'conversations',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      user_id: { type: 'UUID', references: 'users.id', index: true },
      title: { type: 'VARCHAR(255)' },
      agent_id: { type: 'UUID', nullable: true, index: true },
      status: { type: 'VARCHAR(50)', default: "'active'" },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      updated_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  Message: {
    table: 'messages',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      conversation_id: { type: 'UUID', references: 'conversations.id', index: true },
      role: { type: 'VARCHAR(50)', index: true },
      content: { type: 'TEXT' },
      files: { type: 'JSONB', default: '[]' },
      tool_calls: { type: 'JSONB', default: '[]' },
      metadata: { type: 'JSONB', default: '{}' },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  Project: {
    table: 'projects',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      user_id: { type: 'UUID', references: 'users.id', index: true },
      name: { type: 'VARCHAR(255)' },
      description: { type: 'TEXT', nullable: true },
      status: { type: 'VARCHAR(50)', default: "'planning'" },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      updated_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  Task: {
    table: 'tasks',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      project_id: { type: 'UUID', references: 'projects.id', index: true },
      title: { type: 'VARCHAR(255)' },
      description: { type: 'TEXT', nullable: true },
      status: { type: 'VARCHAR(50)', default: "'pending'" },
      priority: { type: 'VARCHAR(50)', default: "'medium'" },
      assigned_agent: { type: 'VARCHAR(255)', nullable: true },
      dependencies: { type: 'JSONB', default: '[]' },
      due_date: { type: 'TIMESTAMP', nullable: true },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      updated_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  Skill: {
    table: 'skills',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      name: { type: 'VARCHAR(255)', unique: true, index: true },
      description: { type: 'TEXT' },
      category: { type: 'VARCHAR(50)', index: true },
      icon: { type: 'VARCHAR(255)' },
      version: { type: 'VARCHAR(50)' },
      enabled: { type: 'BOOLEAN', default: 'true' },
      metadata: { type: 'JSONB', default: '{}' },
      prompts: { type: 'JSONB', default: '[]' },
      tools: { type: 'JSONB', default: '[]' },
      permissions: { type: 'JSONB', default: '[]' },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      updated_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  Memory: {
    table: 'memories',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      user_id: { type: 'UUID', references: 'users.id', index: true },
      type: { type: 'VARCHAR(50)', index: true },
      content: { type: 'TEXT' },
      embedding: { type: 'vector(1536)', nullable: true, index: true },
      metadata: { type: 'JSONB', default: '{}' },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      updated_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      expires_at: { type: 'TIMESTAMP', nullable: true },
    },
  },

  Artifact: {
    table: 'artifacts',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      project_id: { type: 'UUID', references: 'projects.id', index: true },
      type: { type: 'VARCHAR(50)', index: true },
      title: { type: 'VARCHAR(255)' },
      content: { type: 'TEXT' },
      metadata: { type: 'JSONB', default: '{}' },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      updated_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  FileReference: {
    table: 'file_references',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      user_id: { type: 'UUID', references: 'users.id', index: true },
      name: { type: 'VARCHAR(255)' },
      mime_type: { type: 'VARCHAR(255)' },
      size: { type: 'BIGINT' },
      path: { type: 'TEXT' },
      uploaded_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
    },
  },

  ApiKey: {
    table: 'api_keys',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      user_id: { type: 'UUID', references: 'users.id', index: true },
      name: { type: 'VARCHAR(255)' },
      key_hash: { type: 'VARCHAR(255)', unique: true, index: true },
      last_used: { type: 'TIMESTAMP', nullable: true },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP' },
      expires_at: { type: 'TIMESTAMP', nullable: true },
    },
  },

  AuditLog: {
    table: 'audit_logs',
    columns: {
      id: { type: 'UUID', primary: true, default: 'gen_random_uuid()' },
      user_id: { type: 'UUID', nullable: true, references: 'users.id', index: true },
      action: { type: 'VARCHAR(255)', index: true },
      resource: { type: 'VARCHAR(255)' },
      resource_id: { type: 'UUID', nullable: true },
      changes: { type: 'JSONB', default: '{}' },
      ip_address: { type: 'VARCHAR(45)', nullable: true },
      user_agent: { type: 'TEXT', nullable: true },
      created_at: { type: 'TIMESTAMP', default: 'CURRENT_TIMESTAMP', index: true },
    },
  },
} as const;

// Export types for usage
export type ModelName = keyof typeof MODELS;
export type ModelSchema = (typeof MODELS)[ModelName];
