import type { PlanStep, ToolCall } from '@welvox/types';

export interface ExecutionResult {
  stepId: string;
  success: boolean;
  output: unknown;
  error?: string;
  duration: number;
  toolCalls: ToolCall[];
}

export class TaskExecutor {
  private runningTasks: Map<string, Promise<ExecutionResult>> = new Map();

  async executeStep(step: PlanStep, context: Record<string, unknown>): Promise<ExecutionResult> {
    const startTime = Date.now();

    try {
      // Simulate skill execution
      const output = await this.simulateSkillExecution(step, context);

      return {
        stepId: step.id,
        success: true,
        output,
        duration: Date.now() - startTime,
        toolCalls: [],
      };
    } catch (error) {
      return {
        stepId: step.id,
        success: false,
        output: null,
        error: String(error),
        duration: Date.now() - startTime,
        toolCalls: [],
      };
    }
  }

  async executeStepsSequentially(
    steps: PlanStep[],
    context: Record<string, unknown> = {}
  ): Promise<ExecutionResult[]> {
    const results: ExecutionResult[] = [];
    const executionContext = { ...context };

    for (const step of steps) {
      const result = await this.executeStep(step, executionContext);
      results.push(result);

      if (!result.success) {
        // Stop on error
        break;
      }

      // Pass output to next step
      executionContext[step.id] = result.output;
    }

    return results;
  }

  async executeStepsParallel(
    steps: PlanStep[],
    context: Record<string, unknown> = {}
  ): Promise<ExecutionResult[]> {
    const promises = steps.map((step) => this.executeStep(step, context));
    return Promise.all(promises);
  }

  private async simulateSkillExecution(
    step: PlanStep,
    context: Record<string, unknown>
  ): Promise<unknown> {
    // Simulate async execution
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          skill: step.name,
          timestamp: new Date().toISOString(),
          context,
          status: 'completed',
        });
      }, Math.random() * 2000); // 0-2 seconds
    });
  }

  async executeWithRetry(
    step: PlanStep,
    context: Record<string, unknown>,
    maxRetries = 3
  ): Promise<ExecutionResult> {
    let lastError: ExecutionResult | null = null;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const result = await this.executeStep(step, context);
        if (result.success) {
          return result;
        }
        lastError = result;
      } catch (error) {
        lastError = {
          stepId: step.id,
          success: false,
          output: null,
          error: `Attempt ${attempt + 1}: ${String(error)}`,
          duration: 0,
          toolCalls: [],
        };
      }

      // Exponential backoff
      if (attempt < maxRetries - 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }

    return lastError || {
      stepId: step.id,
      success: false,
      output: null,
      error: 'Max retries exceeded',
      duration: 0,
      toolCalls: [],
    };
  }

  cancelTask(taskId: string): void {
    this.runningTasks.delete(taskId);
  }

  getRunningTasks(): string[] {
    return Array.from(this.runningTasks.keys());
  }
}

export const executor = new TaskExecutor();
