import type {
  IntentDetection,
  ExecutionPlan,
  PlanStep,
  WorkflowExecution,
  Skill,
} from '@welvox/types';
import { getAllDefaultSkills } from '@welvox/skills';

export interface OrchestratorConfig {
  model: string;
  temperature: number;
  maxTokens: number;
}

export class Orchestrator {
  private skills: Map<string, Skill> = new Map();
  private config: OrchestratorConfig;

  constructor(config: OrchestratorConfig = {
    model: 'claude-opus-4-1',
    temperature: 0.7,
    maxTokens: 2000,
  }) {
    this.config = config;
    this.initializeSkills();
  }

  private initializeSkills(): void {
    const defaultSkills = getAllDefaultSkills();
    for (const skill of defaultSkills) {
      this.skills.set(skill.id, skill);
    }
  }

  /**
   * Detect user intent and create execution plan
   */
  async detectIntent(userInput: string): Promise<IntentDetection> {
    // Analyze user input to understand intent
    const intent = this.parseIntent(userInput);
    const suggestedSkills = this.selectSkills(intent);
    const executionPlan = this.createPlan(intent, suggestedSkills);

    return {
      intent,
      confidence: this.calculateConfidence(userInput, intent),
      suggestedSkills,
      requiredTools: this.gatherRequiredTools(suggestedSkills),
      executionPlan,
    };
  }

  /**
   * Parse user input to extract intent
   */
  private parseIntent(input: string): string {
    // Simple intent parsing - in production, use LLM
    const keywords: Record<string, string> = {
      'write|create|generate|draft': 'content_creation',
      'code|implement|build|develop': 'coding',
      'analyze|research|study|learn': 'research',
      'plan|organize|schedule': 'planning',
      'automate|workflow|process': 'automation',
      'read|parse|extract': 'file_analysis',
      'email|message|send|communicate': 'communication',
      'data|statistics|chart|graph': 'data_analysis',
      'help|explain|understand': 'general_assistance',
    };

    const lowerInput = input.toLowerCase();
    for (const [pattern, intent] of Object.entries(keywords)) {
      if (new RegExp(pattern).test(lowerInput)) {
        return intent;
      }
    }

    return 'general_assistance';
  }

  /**
   * Select appropriate skills for the intent
   */
  private selectSkills(intent: string): string[] {
    const skillMap: Record<string, string[]> = {
      content_creation: ['skill_content_creator', 'skill_email_writer'],
      coding: ['skill_coding_expert', 'skill_automation_expert'],
      research: ['skill_research_agent', 'skill_data_analyst'],
      planning: ['skill_project_planner', 'skill_universal_assistant'],
      automation: ['skill_automation_expert', 'skill_coding_expert'],
      file_analysis: ['skill_file_analyzer', 'skill_data_analyst'],
      communication: ['skill_email_writer', 'skill_content_creator'],
      data_analysis: ['skill_data_analyst', 'skill_file_analyzer'],
      general_assistance: ['skill_universal_assistant'],
    };

    return skillMap[intent] || ['skill_universal_assistant'];
  }

  /**
   * Create execution plan
   */
  private createPlan(intent: string, skillIds: string[]): ExecutionPlan {
    const steps: PlanStep[] = [];

    for (const skillId of skillIds) {
      const skill = this.skills.get(skillId);
      if (!skill) continue;

      steps.push({
        id: `step_${steps.length + 1}`,
        name: skill.name,
        description: `Execute ${skill.name} skill`,
        skill: skillId,
        tools: skill.tools.map((t) => t.id),
        inputs: {},
        expectedOutputs: this.getExpectedOutputs(skill),
        dependencies: steps.length > 0 ? [steps[steps.length - 1].id] : [],
      });
    }

    return {
      steps,
      estimatedDuration: steps.length * 5000, // 5s per step
      requiredResources: this.gatherResources(skillIds),
    };
  }

  /**
   * Get expected outputs for a skill
   */
  private getExpectedOutputs(skill: Skill): string[] {
    const schema = skill.metadata.outputSchema;
    if (typeof schema === 'object' && schema !== null) {
      return Object.keys(schema);
    }
    return ['result'];
  }

  /**
   * Gather all required tools
   */
  private gatherRequiredTools(skillIds: string[]): string[] {
    const tools = new Set<string>();

    for (const skillId of skillIds) {
      const skill = this.skills.get(skillId);
      if (skill) {
        skill.tools.forEach((t) => tools.add(t.id));
      }
    }

    return Array.from(tools);
  }

  /**
   * Gather required resources
   */
  private gatherResources(skillIds: string[]): string[] {
    const resources = new Set<string>();

    for (const skillId of skillIds) {
      const skill = this.skills.get(skillId);
      if (skill) {
        skill.metadata.requiredTools.forEach((t) => resources.add(t));
      }
    }

    return Array.from(resources);
  }

  /**
   * Calculate confidence score
   */
  private calculateConfidence(input: string, intent: string): number {
    // Simple confidence calculation
    if (input.length < 10) return 0.5;
    if (intent === 'general_assistance') return 0.7;
    return 0.85;
  }

  /**
   * Execute workflow
   */
  async executeWorkflow(plan: ExecutionPlan): Promise<WorkflowExecution> {
    const execution: WorkflowExecution = {
      id: this.generateId(),
      workflowId: this.generateId(),
      userId: '',
      steps: [],
      status: 'running',
      startedAt: new Date(),
    };

    for (const step of plan.steps) {
      // Execute each step
      const skill = this.skills.get(step.skill);
      if (!skill) continue;

      const stepExecution = {
        id: step.id,
        name: step.name,
        action: skill.name,
        inputs: step.inputs,
        outputs: {},
        status: 'completed' as const,
        agentId: skill.id,
      };

      execution.steps.push(stepExecution);
    }

    execution.status = 'completed';
    execution.completedAt = new Date();

    return execution;
  }

  private generateId(): string {
    return `${Date.now()}_${Math.random().toString(36).substring(7)}`;
  }

  /**
   * Register a custom skill
   */
  registerSkill(skill: Skill): void {
    this.skills.set(skill.id, skill);
  }

  /**
   * Get all registered skills
   */
  getSkills(): Skill[] {
    return Array.from(this.skills.values());
  }

  /**
   * Get skill by ID
   */
  getSkill(id: string): Skill | undefined {
    return this.skills.get(id);
  }
}

// Singleton instance
export const orchestrator = new Orchestrator();
